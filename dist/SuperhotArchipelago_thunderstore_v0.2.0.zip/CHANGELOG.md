# Changelog

## 0.2.0

- Removed the author's personal name from every public-facing spot: mod metadata,
  LICENSE, the Archipelago tutorial listing, and the sample player file (now
  `superhot_example.yaml`, slot `Player1`).
- New Thunderstore icon.
- No gameplay or behavior changes from 0.1.1 -- this is a housekeeping release.


## 0.1.1

- Removed the "LOCKED" / "Return to hub to continue" popups shown when walking into a
  still-locked level — the block itself (redirect to hub, input suppression) is
  unchanged, it's just silent now.
- A blocked click during the SUPERHOT title-card sequence now redirects to the hub
  instead of silently doing nothing.
- In-game popup notifications now use a mod-owned overlay rendered with the game's real
  terminal font, with a JSON tuning file for live-adjusting size/position/timing.
- Word-wrap and configurable width/height caps for the popup box.
- Archipelago mode can be toggled on/off in-game without uninstalling the mod.
- In-game notification log (`AP LOG`) and per-classification popup filters
  (`ARCHIPELAGO > SETTINGS`).
- `34 - Free` (the real ending) requires a configurable number of other levels completed
  first, not just its own access item.
- Optional `exclude_slow_levels` YAML setting to drop the four slowest levels from the
  item/location pool entirely.
